# Homework 06
# Exercise: compute the area and the perimeter of a rectangle

def area(base, height):
    return base * height

def perimeter(base, height):
    return 2 * (base + height)

string = "text"

base = 5
height = 3
print("Area:", area(base, height))
print("Perimeter:", perimeter(base, height))
